/*
* PLEASE WRITE DOWN FOLLOWING INFO BEFORE SUBMISSION
* FILE NAME: main_3036065642.c, inference_3036065642.c, report
* NAME: TSE Wang Pok
* UID:  3036065642
* Development Platform: Workbench2.cs.hku.hk on Visual Studio Code
* Remark: (How much you implemented?) All
* How to compile separately: (gcc -o main main_[UID].c): make -B
*/

#include "common.h"  // common definitions
#include <stdio.h>   // for printf, fgets, scanf, perror
#include <stdlib.h>  // for exit() related
#include <unistd.h>  // for folk, exec...
#include <wait.h>    // for waitpid
#include <signal.h>  // for signal handlers and kill
#include <string.h>  // for string related 
#include <sched.h>   // for sched-related
#include <syscall.h> // for syscall interface

#define READ_END       0    // helper macro to make pipe end clear
#define WRITE_END      1    // helper macro to make pipe end clear
#define SYSCALL_FLAG   0    // flags used in syscall, set it to default 0

// Define Global Variable, Additional Header, and Functions Here
int child_progress = 1;
//set the initial utime and stime be 0
int prev_utime = 0;
int prev_stime = 0;

void sigusrHandler(int sig_num)
{
    child_progress = 0;//when the child finish, update this value to 0, so that exit the while loop!
    printf("receive signal from child\n");
}

//this function is used for getting the cpu usage
double cpu_usage(int current_utime, int current_stime, int previous_utime, int previous_stime){
    int diff_u = current_utime - previous_utime;
    int diff_s = current_stime - previous_stime;
    double result = (diff_u + diff_s) / 0.3;
    return result;
}

//get the /proc/pid/stat function
void get_proc_stats(int pid, int *prev_utime, int *prev_stime){
    char stat_file[100];
    sprintf(stat_file, "/proc/%d/stat", pid);//write the info into file
    FILE *file = fopen(stat_file, "r");

    //things we want
    int pid_num;
    int utime;
    int stime;
    int task_cpu;
    char tcomm[100];
    char state;
    int policy;
    int nice;
    int vsize;
    double cpu_percent;
    //parse the stat file and get the required info
    //from file read in (add * can skip the value)
    fscanf(file, "%d %s %c %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %d %d %*d %*d %*d %d %*d %*d %*d %d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %d %*d %d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d", &pid_num, tcomm, &state, &utime, &stime, &nice, &vsize, &task_cpu, &policy);
    fclose(file);

    const char *policy_name = get_sched_name(policy);//convert policy from int to string

    //calculate the cpu_percent
    cpu_percent = cpu_usage(utime, stime, *prev_utime, *prev_stime);

    //print to stderr
    fprintf(stderr, "[pid] %d [tcomm] %s [state] %c [policy] %s [nice] %d [vsize] %d [task_cpu] %d [utime] %d [stime] %d [cpu%%] %.2f%%\n",pid_num,tcomm,state,policy_name,nice,vsize,task_cpu,utime,stime, cpu_percent);
    *prev_utime = utime;//update the previous s/utime
    *prev_stime = stime;
}

int main(int argc, char *argv[]) {

    signal(SIGUSR1, sigusrHandler);

    char prompts[512];// prompt strings
    char* seed; 
    if (argc == 2) {
        seed = argv[1];
    } else if (argc == 1) {
        // use 42, the answer to life the universe and everything, as default
        seed = "42";
    } else {
        fprintf(stderr, "Usage: ./main <seed>\n");
        fprintf(stderr, "Note:  default seed is 42\n");
        exit(1);
    }

    //create a pipe
    int parent_to_child[2];
    pipe(parent_to_child);

    pid_t pid = fork();//create a child process

    if (pid < 0)
    {
        printf("fork error\n");
        exit(1);
    }
    else if (pid == 0)
    {
        //set the schedule policy
        struct sched_attr attr;
        attr.size = sizeof(struct sched_attr);
        attr.sched_policy = SCHED_IDLE;
        attr.sched_nice = 0;
        syscall(SYS_sched_setattr, 0, &attr, 0);//make the system call to change the settings

        //execute the inference.c
        close(parent_to_child[1]);//close the write end
        dup2(parent_to_child[0], 0);//redirect the stdin to the child process

        execlp("./inference", "inference", seed, NULL);
    }
    else
    {
        int status;//store the exit status of child process
        close(parent_to_child[0]);//close the read end

        for(int i = 0; i < 4; i++){
            printf(">>> ");
            fgets(prompts, sizeof(prompts), stdin);//send prompts to the child process
            write(parent_to_child[1], prompts, strlen(prompts));
            while(child_progress){
                //wait for child process finish generate(if child finish then child_progress = 0)
                //at the same time, read /proc stats every 300ms
                get_proc_stats(pid, &prev_utime, &prev_stime);
                usleep(300000);//sleep for 300ms
            }
            child_progress = 1;//set back child_progress = 1
        }
        waitpid(-1, &status, 0);

        //collect the exit status
        printf("exit status of child process: %d\n", status);
        
    }
    return EXIT_SUCCESS;
}